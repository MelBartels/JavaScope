import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.colorchooser.*;
import javax.swing.filechooser.*;
import javax.accessibility.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
import java.io.*;
import java.text.*;
import java.net.*;

/**
 * position error class: class containing altazimuth coordinates, altazimuth errors, and links to prev/next classes
 */
public class posErr {
    azDouble az = new azDouble();
    azDouble azErr = new azDouble();
}


